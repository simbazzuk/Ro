import uvicorn
from fastapi import FastAPI
import re
from schema import ResearchPayModel

def calculate_risk(results):
    total_words = len(results)
    words_found = sum(results.values())
    percentage = (words_found / total_words) * 100
    risk_rating = "Low" if percentage > 80 else "High"

    return risk_rating

app = FastAPI()

@app.get("/")
def status_check():
    return {"status": "API launched Successfully"}


@app.post("/api/search_para")
def check_words(data: ResearchPayModel) -> dict:
    para = data.paragraph.lower()
    results = {word: 0 for word in data.keywords}

    for word in data.keywords:
        pattern = r'\b' + re.escape(word.lower()) + r'\b'
        if re.search(pattern, para):
            results[word] += 1
    risk = calculate_risk(results)
    results.update({"risk_rating": risk})

    return results

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)