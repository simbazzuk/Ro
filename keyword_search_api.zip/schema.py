from pydantic import BaseModel
from typing import List

class ResearchPayModel(BaseModel):
    paragraph: str
    keywords: List[str]
