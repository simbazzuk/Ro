# Keyword Search API

## Requirements

- Python 3.10+
- FastAPI
- Uvicorn

## Installation

1. Install the required packages:
   ```
   pip install fastapi uvicorn
   ```

## Usage

1. Start the server:
   ```
   python main.py
   ```
   The API will be available at `http://127.0.0.1:8000`.

2. Use the API endpoints:

   - GET `/`: Check if the API is running
   - POST `/api/search_para`: Search for keywords in a paragraph

### API Endpoints

#### POST /api/search_para

Searches for keywords in the given paragraph and calculates a risk rating.

Request body:
```json
{
  "paragraph": "Your paragraph text here",
  "keywords": ["word1", "word2", "word3"]
}
```

Example response:
```json
{
  "word1": 1,
  "word2": 0,
  "word3": 2,
  "risk_rating": "Low"
}
```

See the usage at  `http://127.0.0.1:8000/docs`.
 