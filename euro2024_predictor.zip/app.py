import random
import streamlit as st
from datetime import datetime


if 'fixtures' not in st.session_state:
    st.session_state['fixtures'] = [
        "14/06/2024 Germany vs Scotland",
        "15/06/2024 Hungary vs Switzerland",
        "15/06/2024 Spain vs Croatia",
        "15/06/2024 Italy vs Albania",
        "16/06/2024 Poland vs Netherlands",
        "16/06/2024 Slovenia vs Denmark",
        "16/06/2024 Serbia vs England",
        "17/06/2024 Romania vs Ukraine",
        "17/06/2024 Belgium vs Slovakia",
        "17/06/2024 Austria vs France"
    ]
def roll_dice():
    rolls = [random.randint(1, 6) for _ in range(3)]
    return sum(rolls)

def determine_winner(fixture, threshold):
    date, match = fixture.split(" ", 1)
    team1, team2 = match.split(" vs ")
    team1_score = roll_dice()

    if team1_score >= threshold:
        winner = team1
    else:
        winner = team2

    return f"{date} {team1} - {team2} | Winner: {winner}"

def run_fixtures(fixtures, threshold):
    results = []
    for fixture in fixtures:
        result = determine_winner(fixture, threshold)
        results.append(result)

    return results

def main():
    fixtures = st.session_state['fixtures']
    st.title("Euro2024 Match Prediction App")

    st.sidebar.title("Manage Fixtures and Threshold")
    new_fixture = st.sidebar.text_input("Add Fixture (date team1 vs team2)")
    if st.sidebar.button("Add Fixture"):
        fixtures.append(new_fixture)
        st.sidebar.success(f"New fixture '{new_fixture}' added successfully.")

    fixture_to_remove = st.sidebar.text_input("Remove Fixture (date team1 vs team2)")
    if st.sidebar.button("Remove Fixture"):
        if fixture_to_remove in fixtures:
            fixtures.remove(fixture_to_remove)
            st.sidebar.success(f"Fixture '{fixture_to_remove}' removed successfully.")
        else:
            st.sidebar.warning(f"Fixture '{fixture_to_remove}' not found in the list.")

    threshold = st.sidebar.number_input("Set Winning Threshold (1-18)", value=10, step=1)
    if threshold > 18:
        st.warning("Threshold cannot be greater than 18.")
        st.stop()

    st.subheader("Current Fixtures")
    sorted_fixtures = sorted(fixtures, key=lambda x: datetime.strptime(x.split(" ")[0], "%d/%m/%Y"))
    for fixture in sorted_fixtures:
        st.write(fixture)

    if st.button("Predict Winners"):
        results = run_fixtures(sorted_fixtures, threshold)
        st.subheader("Match Results")
        for result in results:
            st.write(result)

if __name__ == "__main__":
    main()