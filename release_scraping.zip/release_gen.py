from bs4 import BeautifulSoup
import requests
import csv

url = 'https://cloud.google.com/composer/docs/release-notes'
response = requests.get(url)
html_content = response.text

soup = BeautifulSoup(html_content, 'html.parser')

releases_section = soup.find('section', class_="releases")
h2_elements = releases_section.find_all('h2')
div_elements = releases_section.find_all('div')

mapping = {}
current_h2 = None

for element in soup.find_all(['h2', 'div']):
    if element.name == 'h2':
        current_h2 = element.get_text(strip=True).replace(',','')
        mapping[current_h2] = []
    elif element.name == 'div' and current_h2:
        classname = element.get('class')[0]
        if classname.startswith('release-'):
            mapping[current_h2].append(classname.replace('release-', ''))

def link_gen(date):
    return f"{url}#{date.replace(' ', '_')}"


with open('release_tracker.csv', 'w', newline='') as csvfile:
    writer = csv.writer(csvfile)

    writer.writerow(['release_date', 'release_type', 'release_link'])

    for date, types in mapping.items():
        for rel_type in types:
            writer.writerow([date, rel_type, link_gen(date)])


print("CSV file 'release_tracker.csv' has been created successfully.")